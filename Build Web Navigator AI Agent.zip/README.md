
  # Build Web Navigator AI Agent

  This is a code bundle for Build Web Navigator AI Agent. The original project is available at https://www.figma.com/design/kEr7HeuPLHqVaz02lEgbhU/Build-Web-Navigator-AI-Agent.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  